#!/bin/bash

clear

figlet SHA - 1 Crack

echo -n "Informe o Hash que deseja quebrar: "
read hash
echo " "

echo "::::::::::: SHA1 CRACK :::::::::::"
echo " "

cat HashSha1.txt | grep "$hash" | uniq
echo " "
echo ":::::::::::::::::::::::::::::::::"

echo ""
