#!/bin/bash

clear

echo

figlet Sha - 1 Generate
                                                          
echo -n "Digite uma palavra para converter em SHA-1: "
read palavra
echo ""
                                                            
echo "::::::::::::SHA1 GENERATE:::::::::::::"
echo ""

echo -n "$palavra : " >> HashSha1.txt
echo -n "$palavra" | sha1sum | cut -d " " -f 1 >> HashSha1.txt

tail -n 1 HashSha1.txt
echo " "
echo "::::::::::::::::::::::::::::::::::::::"
echo ""
