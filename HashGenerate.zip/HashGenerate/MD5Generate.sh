#!/bin/bash

clear

echo

figlet MD5Generate
                                                          
echo -n "Digite uma palavra para converter em MD5: "
read palavra
echo ""
                                                            
echo "::::::::::::MD5 GENERATE:::::::::::::"
echo ""

echo -n "$palavra : " >> HashMD5.txt
echo -n "$palavra" | md5sum | cut -d " " -f 1 >> HashMD5.txt

tail -n 1 HashMD5.txt
echo " "
echo "::::::::::::::::::::::::::::::::::::"
echo ""
