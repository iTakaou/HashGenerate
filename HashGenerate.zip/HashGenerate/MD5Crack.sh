#!/bin/bash

clear

figlet MD5Crack

echo -n "Informe o Hash que deseja quebrar: "
read hash
echo " "

echo "::::::::::: MD5 CRACK :::::::::::"
echo " "

cat HashMD5.txt | grep "$hash" | uniq
echo " "
echo ":::::::::::::::::::::::::::::::::"

echo ""
